class Funcionario:
    def __init__(self, nome:str, salario:float, setor:str, carga_horaria:str):
        self.nome = nome
        self.salario = salario
        self.setor = setor
        self.carga_horaria = carga_horaria
