from arquivoCarro import Carro
from arquivoMoto import Moto

carro1 = Carro('Audi', 'Audi TT', 2023, 2)

print(carro1.informacoes())
print(carro1.mover())

moto1 = Moto('Honda', 'XRE 300', 2024, 'Oco')

print(moto1.informacoes())
print(moto1.mover())

