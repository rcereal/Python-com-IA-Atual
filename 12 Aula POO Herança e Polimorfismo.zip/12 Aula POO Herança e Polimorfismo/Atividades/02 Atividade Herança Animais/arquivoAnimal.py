class Animal:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade

    def som(self,som_do_animal):
        return 'O Animal faz'

